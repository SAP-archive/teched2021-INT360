var task = $.usertasks.firstApprovalForSO.last;
var approvalDecision = task.decision;
var decision = {
	"LastProcessor": task.processor,
	"Decision": approvalDecision,
	"Comments": $.context.Comments
};
// $.context.History.push(decision);
$.context.wfi_decision = approvalDecision
$.context.wfi_lastapprover = task.processor
