sap.ui.define([
	"comsap.bpm.wfi./salesorder-task-ui/test/unit/controller/SalesOrderTaskUI.controller"
], function () {
	"use strict";
});
