/*global QUnit*/

sap.ui.define([
	"comsap.bpm.wfi./salesorder-task-ui/controller/SalesOrderTaskUI.controller"
], function (Controller) {
	"use strict";

	QUnit.module("SalesOrderTaskUI Controller");

	QUnit.test("I should test the SalesOrderTaskUI controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
