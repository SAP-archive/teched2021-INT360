sap.ui.define([], function (DateFormat, I18n, Constants, FormatMessage) {
    "use strict";

    return {
        formatPercentage: function (dValue) {
            if (dValue == 0.0 || !dValue || isNaN(dValue) || dValue > 1) {
                return "";
            }
            // round to two decimal places and display as percentage string
            return parseFloat(dValue * 100).toFixed(2) + " %";
        }
    };
});
